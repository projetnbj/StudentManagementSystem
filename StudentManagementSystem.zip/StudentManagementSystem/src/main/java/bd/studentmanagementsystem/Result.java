/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.studentmanagementsystem;

/**
 *
 * @author Projet
 */
public class Result {
    Subject subject;
    double resultMarks;
  
    
    public Result(Subject subject, double resultMarks){
    this.subject=subject;
    this.resultMarks=resultMarks;
   
    
    
    
    }
            
}
