/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.studentmanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author Projet
 */
public class Subject {
    String subjectName;
    int subjectId;

    
    public Subject (String subjectName, int subjectId){
    this.subjectId=subjectId;
    this.subjectName=subjectName;
    
    }
}
