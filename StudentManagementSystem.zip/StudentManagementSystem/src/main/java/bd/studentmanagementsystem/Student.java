/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.studentmanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author Projet
 */
public class Student {
    int studentId;
    String studentName;
    ArrayList<Result> results=new ArrayList<>();
    
    public Student(int studentId, String studentName){
    
        this.studentId=studentId;
        this.studentName=studentName;
        this.results= new ArrayList<>();
    
    }
    
}
