/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.studentmanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author Projet
 */
public class StudentSystem {
    
    ArrayList<Student> students= new ArrayList<>();
    ArrayList<Subject> subjects=new ArrayList<>();
    
    public StudentSystem(){
    this.students=new ArrayList<>();
    this.subjects=new ArrayList<>();
    
    }
    
    public String addStudent(Student student){
    students.add(student);
    return "Student added successfully";
    }
    public String addSubject(Subject subject){
    subjects.add(subject);
    return "Subject added successfully";
    }
    
  public String calculateAverage(Student student) {
    if (student.results.isEmpty()) {
        return "No results available for " + student.studentName;
    }

    double total = 0;
    for (Result r : student.results) {
        total += r.resultMarks;
    }

    double average = total / student.results.size();
    return "Average score for " + student.studentName + " is " + average;
}

    
    
    
}
