/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package bd.studentmanagementsystem;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Projet
 */
public class StudentManagementSystem {

    public static void main(String[] args) {
        
        Scanner scan= new Scanner(System.in);
        StudentSystem sys=new StudentSystem();
        DatabaseManager db=new DatabaseManager();
        Connection conn=db.conn();
        db.createTable(conn);
         while(true){
         
             System.out.println("Choose an option below : ");
             System.out.println("1. Add a student");
             System.out.println("2. Add a subject");
             System.out.println("3. Display result for student");
             System.out.println("4. Display results for all students");
             System.out.println(" 5. Exir");
             int choice=scan.nextInt();

             switch(choice){
             
    case 1: 
        System.out.println("Enter the student name");
        scan.nextLine(); // consume newline
        String name = scan.nextLine();
        System.out.println("Enter the student id");
        int studentId = scan.nextInt();

        Student stud = new Student(studentId, name);
        System.out.println(sys.addStudent(stud));

        // Save to DB
       
        db.insertStudent(conn, stud);

        break;

    case 2: 
        System.out.println("Enter the subject name ");
        scan.nextLine(); // consume newline
        String subjectName = scan.nextLine();
        System.out.println("Enter the subject id");
        int subjectId = scan.nextInt();

        Subject subject = new Subject(subjectName, subjectId);
        System.out.println(sys.addSubject(subject));

        // Optionally attach subject to a student with a score
        System.out.println("Enter student id to assign this subject:");
        int sid = scan.nextInt();
        System.out.println("Enter score for " + subjectName + ":");
        double score = scan.nextDouble();

        Result result = new Result(subject, score);

        // Find student in system
        for (Student s : sys.students) {
            if (s.studentId == sid) {
                s.results.add(result);
                db.updateResult(conn, sid, subjectName, score);
                System.out.println("Result added for " + s.studentName);
            }
        }
        break;

    case 3:
        System.out.println("Enter student id to view results:");
        int sidView = scan.nextInt();
        Student loadedStudent = db.getResultsForStudent(conn, sidView);
        if (loadedStudent != null) {
            System.out.println("Student: " + loadedStudent.studentName);
            for (Result r : loadedStudent.results) {
                System.out.println("Subject: " + r.subject.subjectName + " | Score: " + r.resultMarks);
            }
            System.out.println( sys.calculateAverage(loadedStudent));
        } else {
            System.out.println("Student not found.");
        }
        break;
        
    case 4:
          ArrayList<Student> allStudents = db.getAllStudents(conn);
    if (allStudents.isEmpty()) {
        System.out.println("No students found.");
    } else {
        for (Student s : allStudents) {
            System.out.println("Student: " + s.studentName);
            System.out.println(sys.calculateAverage(s));
            System.out.println("----------------------");
        }
    }
    break;

    case 5:
        System.out.println("We were glad to have you today!");
        System.exit(0);
        break;

    default: 
        System.out.println("Invalid choice");
        break;
}
                     
         }
             
         }
        
    }

