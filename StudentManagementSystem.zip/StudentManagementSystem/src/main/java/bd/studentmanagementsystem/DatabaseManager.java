/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.studentmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Projet
 */
public class DatabaseManager {
    
    public Connection conn(){
    
        Connection conn;
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:school.db");
            System.out.println("Conection was successful");
            return conn;
        } catch (SQLException e) {
            System.out.println("Connection to database failed "+ e.getMessage());;
    return null;
        }
        
    }
    public void createTable(Connection conn){
    String sqlStudents = "CREATE TABLE IF NOT EXISTS students ("
        + "studentId TEXT PRIMARY KEY,"
        + "studentName TEXT)";

String sqlResults = "CREATE TABLE IF NOT EXISTS results ("
        + "resultId INTEGER PRIMARY KEY AUTOINCREMENT,"
        + "studentId TEXT,"
        + "subject TEXT,"
        + "score INT DEFAULT 0,"
        + "FOREIGN KEY(studentId) REFERENCES students(studentId))";
    
    Statement stmt;
        try {
            stmt = conn.createStatement();
            stmt.execute(sqlStudents);
                        stmt.execute(sqlResults);
            System.out.println("Tables created");
        } catch (SQLException e) {
            System.out.println("Could not create the table " + e.getMessage());
        }
    }
    //insert elements into the table
public void insertStudent(Connection conn, Student student){

    String sql="INSERT INTO students (studentId,StudentName) VALUES (?,?)";
    
        try {
            PreparedStatement psmt=conn.prepareStatement(sql);
            psmt.setInt(1, student.studentId);
            psmt.setString(2, student.studentName);
            psmt.executeUpdate();
            System.out.println("Insertion successful");
        } catch (SQLException e) {
            System.out.println("Error inserting data");
}
}
public void insertResult(Connection conn, Result result, int studentId){

    String sql="INSERT INTO results (studentId,subject, score) VALUES (?,?,?)";
    
        try {
            PreparedStatement psmt=conn.prepareStatement(sql);
            psmt.setInt(1, studentId);
            psmt.setString(2, result.subject.subjectName);
             psmt.setDouble(3, result.resultMarks);
            psmt.executeUpdate();
            System.out.println("Insertion successful");
        } catch (SQLException e) {
            System.out.println("Error inserting data into results");
}
}
public Student getResultsForStudent(Connection conn, int studentId) {
    Student student = null;

    // Fetch student info
    String sqlStudent = "SELECT studentId, studentName FROM students WHERE studentId = ?";
    try (PreparedStatement pstmt = conn.prepareStatement(sqlStudent)) {
        pstmt.setInt(1, studentId);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            student = new Student(rs.getInt("studentId"), rs.getString("studentName"));
        }
    } catch (SQLException e) {
        System.out.println("Error fetching student: " + e.getMessage());
    }

    if (student == null) return null;

    // Fetch results
    String sqlResults = "SELECT subject, score FROM results WHERE studentId = ?";
    try (PreparedStatement pstmt = conn.prepareStatement(sqlResults)) {
        pstmt.setInt(1, studentId);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            Subject subject = new Subject(rs.getString("subject"), 0);
            Result result = new Result(subject, rs.getDouble("score"));
            student.results.add(result);
        }
    } catch (SQLException e) {
        System.out.println("Error fetching results: " + e.getMessage());
    }

    return student;
}
public void updateResult(Connection conn, int studentId, String subjectName, double newScore) {
    String sql = "UPDATE results SET score = ? WHERE studentId = ? AND subject = ?";
    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setDouble(1, newScore);
        pstmt.setInt(2, studentId);
        pstmt.setString(3, subjectName);
        int rows = pstmt.executeUpdate();
        if (rows == 0) {
            // If no row exists, insert instead
            insertResult(conn, new Result(new Subject(subjectName, 0), newScore),studentId);
        }
    } catch (SQLException e) {
        System.out.println("Update failed: " + e.getMessage());
    }
}
public ArrayList<Student> getAllStudents(Connection conn) {
    ArrayList<Student> students = new ArrayList<>();
    String sql = "SELECT studentId FROM students";
    try (Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {
        while (rs.next()) {
            int studentId = rs.getInt("studentId");
            Student student = getResultsForStudent(conn, studentId);
            if (student != null) {
                students.add(student);
            }
        }
    } catch (SQLException e) {
        System.out.println("Error fetching all students: " + e.getMessage());
    }
    return students;
}






}
